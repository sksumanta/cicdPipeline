

# how to pull the data from GitHub.
# ansible-playbook -i ../inventories/uat/hosts.yaml  source_control.yaml  -e "theEnv=uat" -e "myDomain=island"


